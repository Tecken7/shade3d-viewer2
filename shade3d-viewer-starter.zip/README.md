# Shade3D Viewer Starter

Online 3D OBJ viewer with transparency sliders for easy GitHub + Vercel deployment.